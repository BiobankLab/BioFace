jQuery(function ($) {

    "use strict"; 
    
 /*
    function animations() {

        animations = new WOW({
            boxClass: 'wow',
            animateClass: 'animated',
            offset: 120,
            mobile: false,
            live: true
        });

        animations.init();

    }
    //WoW Animation.
    animations();
*/
 
   

    // jQuery for page scrolling feature - requires jQuery Easing plugin
    
    $('a.page-scroll').bind('click', function(event) {
        var $anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: ($($anchor.attr('href')).offset().top - 100)
        }, 1250, 'easeInOutExpo');
        event.preventDefault();
    });




$("document").ready(function($){
    var nav = $('.navbar-dark');

    $(window).scroll(function () {
        if ($(this).scrollTop() > 50) {
            nav.addClass("squeeze");
        } else {
            nav.removeClass("squeeze");
        }
    });
});



// https://codepen.io/dmcreis/pen/VLLYPo
var a = 0;
$(window).scroll(function() {

  var oTop = $('#counter').offset().top - window.innerHeight;
  if (a == 0 && $(window).scrollTop() > oTop) {
    $('.banks').each(function() {
      var $this = $(this),
        countTo = $this.attr('data-count');
      $({
        countNum: $this.text()
      }).animate({
          countNum: countTo
        },

        {

          duration: 1000,
          easing: 'swing',
          step: function() {
            $this.text(Math.floor(this.countNum));
          },
          complete: function() {
            $this.text(this.countNum);
            //alert('finished');
          }

        });
    });
    a = 1;
  }

});


var b = 0;
$(window).scroll(function() {

  var oTop = $('#counter2').offset().top - window.innerHeight;
  if (b == 0 && $(window).scrollTop() > oTop) {
    $('.mln').each(function() {
      var $this = $(this),
        countTo = $this.attr('data-count');
      $({
        countNum: $this.text()
      }).animate({
          countNum: countTo
        },

        {

          duration: 1000,
          easing: 'swing',
          step: function() {
            $this.text(Math.floor(this.countNum));
          },
          complete: function() {
            $this.text(this.countNum);
            //alert('finished');
          }

        });
    });
    b = 1;
  }

});





});